<?php $__env->startComponent('mail::message'); ?>
# Nuevo contacto desde Houdle&reg;

<?php echo e($contact['name']); ?> ha solicitado contactarse con el equipo houdle para:
<br>
<?php echo e($contact['description']); ?>

<br>
<br>
Dejo sus datos personales:
<br>
Correo: <?php echo e($contact['email']); ?>

<br>
Teléfono: <?php echo e($contact['phone']); ?>


<?php $__env->startComponent('mail::button', ['url' => 'mailto:'.$contact['email']]); ?>
Contactar
<?php echo $__env->renderComponent(); ?>

Tu bot Houdly! 😎<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\houdle\resources\views/mail/contact-mailable.blade.php ENDPATH**/ ?>