<div>
    <form wire:submit.prevent="submitForm" class="contact-form" method="POST">
        <?php echo csrf_field(); ?>
        <h3>¡Escríbenos!</h3>
        <input wire:model="name" name="name" type="text" class="form-input" placeholder="Nombre">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert-form">
                <p><?php echo e($message); ?></p>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input wire:model="email" name="email" type="email" class="form-input" placeholder="Correo">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert-form">
            <p><?php echo e($message); ?></p>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input wire:model="phone" name="phone" type="phone" class="form-input" placeholder="Teléfono">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert-form">
            <p><?php echo e($message); ?></p>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <textarea wire:model="description" name="description" placeholder="¿Sí tu proyecto hablara que nos diría?" class="form-input"><?php echo e(old('message')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert-form">
            <p><?php echo e($message); ?></p>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" value="Enviar" class="btn">
        <?php if($successMessage): ?>
                <div class="success-message">
                    <p><?php echo e($successMessage); ?></p>
                </div>
        <?php endif; ?>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\houdle\resources\views/livewire/contact.blade.php ENDPATH**/ ?>