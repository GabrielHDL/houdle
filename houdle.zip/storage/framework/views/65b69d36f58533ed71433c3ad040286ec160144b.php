<?php $__env->startComponent('mail::message'); ?>
# ¡Hola <?php echo e($contact['name']); ?>!

Gracias por escribirnos, nos pondremos en contacto contigo lo antes posible.
<br>
<br>
Podrías visitar nuestra página mientras nos ponemos en contacto contigo.
<?php $__env->startComponent('mail::button', ['url' => 'https://houdle.com']); ?>
Ir a Houdle&reg;
<?php echo $__env->renderComponent(); ?>

O visitar nuestro blog y ver los ultimos post sobre tecnología, diseño, criptomonedas y más.

<?php $__env->startComponent('mail::button', ['url' => 'https://blog.houdle.com']); ?>
Ir a Houdle Blog&reg;
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
Un abrazo de parte de todo el equipo <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\houdle\resources\views/mail/answer-mailable.blade.php ENDPATH**/ ?>