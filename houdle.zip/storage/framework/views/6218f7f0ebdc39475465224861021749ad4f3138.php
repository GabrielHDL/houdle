<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

         
         <meta name="Description" content="Agencia digital creativa de experiencias únicas especializada en identidad visual, verbal y estrategia de marca. Para el diseño y personalidad de tu empresa." />
         <meta property="og:title" content="Houdle®" />
         <meta property="og:type" content="website" />
         <meta property="og:description" content="Agencia digital creativa de experiencias únicas especializada en identidad visual, verbal y estrategia de marca. Para el diseño y personalidad de tu empresa." />
         <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
         <meta property="og:site_name" content="Houdle®" />
         <meta property="og:image" content="<?php echo e(asset('assets/open_houdle.jpg')); ?>" />
         <meta propety="og:image:alt" content="<?php echo e(config('app.name', 'Tradeo Logistics')); ?> Open Graph image" />
         <meta property="og:locale" content="es_MX">
         <meta name="twitter:title" content="Houdle®">
         <meta name="twitter:description" content="Agencia digital creativa de experiencias únicas especializada en identidad visual, verbal y estrategia de marca. Para el diseño y personalidad de tu empresa.">
         <meta name="twitter:image" content="<?php echo e(asset('assets/open_houdle.jpg')); ?>">
         <meta name="twitter:site" content="houdlemx">
         <meta name="twitter:creator" content="houdlemx">
 
         
         <meta name="theme-color" content="#F3F5F6">

        <title><?php echo e(config('app.name', 'Houdle®')); ?></title>

        <!-- --------- Scroll Reveal Library --------- -->
        <script src="https://unpkg.com/scrollreveal"></script>
        <!-- --------- CSS Files --------- -->
        <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <link rel="stylesheet" href="./css/style.css">

        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">

        <!-- TrustBox script -->
        <script type="text/javascript" src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js" async></script>
        <!-- End TrustBox script -->

        
        <link rel="icon" href="<?php echo e(asset('favicons/favicon32x32.png')); ?>" sizes="32x32" />
        <link rel="icon" href="<?php echo e(asset('favicons/favicon192x192.png')); ?>" sizes="192x192" />

        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
        <div class="overlay"></div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation')->html();
} elseif ($_instance->childHasBeenRendered('MA3Icsu')) {
    $componentId = $_instance->getRenderedChildComponentId('MA3Icsu');
    $componentTag = $_instance->getRenderedChildComponentTagName('MA3Icsu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MA3Icsu');
} else {
    $response = \Livewire\Livewire::mount('navigation');
    $html = $response->html();
    $_instance->logRenderedChild('MA3Icsu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

        <!-- JavaScript Files -->

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
        <script src="<?php echo e(asset('js/mixitup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app_custom.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\houdle\resources\views/layouts/app.blade.php ENDPATH**/ ?>