<section class="subscription section">
    <div class="container">
      <img src="./assets/map.png" alt="" class="map">
      <div class="sub-box">
        <img src="./assets/square2.png" class="shape square">
        <div class="sub-info">
          <h3 class="sub-heading avenirBold">Suscríbete</h3>
          <h1 class="heading walsheimBold">Mantente al tanto de nuestros proyectos</h1>
          <p class="text">
            ¿Te encanta el diseño, desarrollo y marketing? suscríbete y recibe nuestras últimas noticias.
          </p>
        </div>
        <form wire:submit.prevent="submitForm">
          <input wire:model="email" name="email" type="email" placeholder="Correo" class="form-input">
          <input type="submit" value="Suscríbete" class="btn">
            <?php if($successMessage): ?>
                <div class="success-message">
                    <p><?php echo e($successMessage); ?></p>
                </div>
            <?php elseif($errorMessage): ?>
                <div class="alert-form mt-2">
                    <p><?php echo e($errorMessage); ?></p>
                </div>
            <?php endif; ?>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert-form mt-2">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
      </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\houdle\resources\views/livewire/subscription.blade.php ENDPATH**/ ?>