<?php return array (
  'contact' => 'App\\Http\\Livewire\\Contact',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
  'subscription' => 'App\\Http\\Livewire\\Subscription',
);