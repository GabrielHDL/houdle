<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmailListingController extends Controller
{
    //
}
